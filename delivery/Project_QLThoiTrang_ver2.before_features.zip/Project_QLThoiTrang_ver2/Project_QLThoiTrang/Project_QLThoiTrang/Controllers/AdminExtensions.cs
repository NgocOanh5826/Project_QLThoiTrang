using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Project_QLThoiTrang.Models;
namespace Project_QLThoiTrang.Controllers;
public partial class AdminController
{
 public override void OnActionExecuting(ActionExecutingContext context)
 {
  if(User.IsInRole("Admin"))return;
  string action=context.ActionDescriptor.RouteValues["action"]??"";
  string[] allowed=action switch
  {
   "Index"=>new[]{"Catalog","Inventory","Sales","Support"},
   "Products" or "Product" or "DeleteProduct" or "Categories" or "AddCategory" or "DeleteCategory" or "Promotions" or "Promotion" or "Variants" or "Variant" or "Category"=>new[]{"Catalog"},
   "Inventory" or "Receive" or "ReceiveMany" or "VariantStock" or "AdjustVariant" or "Receipts" or "Receipt" or "StockCount"=>new[]{"Inventory"},
   "Orders" or "Order" or "OrderStatus" or "Payment" or "Returns" or "ResolveReturn" or "Reports" or "Export" or "ReturnRequest"=>new[]{"Sales"},
   "Customers" or "Customer" or "EditCustomer" or "Reviews" or "Moderate"=>new[]{"Support"},
   "References" or "Reference"=>new[]{(context.ActionArguments.Values.OfType<ReferenceInput>().FirstOrDefault()?.Kind??Request.Query["kind"].ToString()) is "warehouses" or "suppliers"?"Inventory":"Catalog"},
   _=>Array.Empty<string>()
  };
  if(!allowed.Any(User.IsInRole))context.Result=Forbid();
 }
 public IActionResult References(string kind="brands",int id=0)
 {if(id>0)return RedirectToAction(nameof(Reference),new{kind,id});try{return View(new ReferencePage{Input=new(){Kind=kind},Rows=store.References(kind)});}catch(InvalidOperationException){return BadRequest();}}
 public IActionResult Reference(string kind="brands",int id=0)
 {try{var rows=store.References(kind);var input=id==0?new ReferenceInput{Kind=kind}:rows.FirstOrDefault(r=>r.Id==id);return input==null?NotFound():View(input);}catch(InvalidOperationException){return BadRequest();}}
 [HttpPost] public IActionResult References(ReferenceInput input)=>Reference(input);
 [HttpPost] public IActionResult Reference(ReferenceInput input)
 {
  try{store.References(input.Kind);}catch(InvalidOperationException){return BadRequest();}
  if(ModelState.IsValid)try{store.SaveReference(input,ActorId);TempData["Success"]="Đã lưu danh mục.";return RedirectToAction(nameof(References),new{kind=input.Kind});}catch(InvalidOperationException ex){ModelState.AddModelError("",ex.Message);}
  return View("Reference",input);
 }
 void ReceiveOptions(){var d=store.Read(d=>d);ViewBag.Products=d.Products;ViewBag.Variants=d.Variants;ViewBag.Warehouses=d.Warehouses.Where(w=>w.Active).ToList();ViewBag.Suppliers=d.Suppliers.Where(s=>s.Active).ToList();}
 void VariantOptions(){ViewBag.Products=store.Read(d=>d.Products);ViewBag.Sizes=store.References("sizes");ViewBag.Colors=store.References("colors");}
 public IActionResult Variants(int? id=null)
 {if(id.HasValue)return RedirectToAction(nameof(Variant),new{id});VariantOptions();ViewBag.Variants=store.Read(d=>d.Variants);return View();}
 public IActionResult Variant(int id=0)
 {VariantOptions();if(id==0)return View(new VariantInput());var r=store.NativeRead(db=>db.BienTheSanPham.SingleOrDefault(v=>v.MaBienThe==id));return r==null?NotFound():View(new VariantInput{Id=r.MaBienThe,ProductId=r.MaSP,SizeId=r.MaKichThuoc,ColorId=r.MaMauSac,Sku=r.SKU,Price=r.GiaBanRieng,Active=r.TrangThai});}
 [HttpPost] public IActionResult Variants(VariantInput input)=>Variant(input);
 [HttpPost] public IActionResult Variant(VariantInput input)
 {if(ModelState.IsValid)try{store.SaveVariant(input,ActorId);TempData["Success"]="Đã lưu biến thể.";return RedirectToAction(nameof(Variants));}catch(InvalidOperationException ex){ModelState.AddModelError("",ex.Message);}VariantOptions();return View("Variant",input);}
 public IActionResult VariantStock()=>View(store.Read(d=>d));
 [HttpPost] public IActionResult AdjustVariant(int variantId,int warehouseId,int quantity,int expected,string reason)
 {try{store.AdjustVariantStock(variantId,warehouseId,quantity,expected,reason,ActorId);TempData["Success"]="Đã kiểm kê biến thể.";}catch(InvalidOperationException ex){TempData["Error"]=ex.Message;}return RedirectToAction(nameof(StockCount),new{variantId,warehouseId});}
 public IActionResult Receipts()=>View(store.NativeRead(db=>db.PhieuNhap.OrderByDescending(p=>p.NgayNhap).ToList()));
 public IActionResult Receipt(int id)
 {var receipt=store.NativeRead(db=>db.PhieuNhap.SingleOrDefault(p=>p.MaPhieuNhap==id));if(receipt==null)return NotFound();ViewBag.Lines=store.NativeRead(db=>db.ChiTietPhieuNhap.Where(l=>l.MaPhieuNhap==id).ToList());return View(receipt);}
 [HttpPost] public IActionResult ReceiveMany(List<ReceiveInput> lines,string reference,int warehouseId,int supplierId)
 {try{foreach(var line in lines){line.Reference=reference;line.WarehouseId=warehouseId;line.SupplierId=supplierId;}try{store.ReceiveBatch(lines,ActorId);}catch(System.ComponentModel.DataAnnotations.ValidationException ex){throw new InvalidOperationException(ex.Message);}TempData["Success"]="Đã nhập toàn bộ phiếu.";}catch(InvalidOperationException ex){TempData["Error"]=ex.Message;}return RedirectToAction(nameof(Receive),new{tab="many"});}
 public IActionResult Staff(int id=0)
 {if(id>0)return RedirectToAction(nameof(StaffMember),new{id});ViewBag.Staff=store.Staff();return View();}
 public IActionResult StaffMember(int id=0)
 {var s=store.Staff().FirstOrDefault(s=>-s.Id==id);return id>0&&s==null?NotFound():View(s==null?new StaffInput():new StaffInput{Id=-s.Id,Name=s.Name,Email=s.Email,Phone=s.Phone,Role=s.Role,Active=s.Active});}
 [HttpPost] public IActionResult Staff(StaffInput input)=>StaffMember(input);
 [HttpPost] public IActionResult StaffMember(StaffInput input)
 {if(ModelState.IsValid)try{store.SaveStaff(input,ActorId);TempData["Success"]="Đã lưu nhân viên và quyền.";return RedirectToAction(nameof(Staff));}catch(InvalidOperationException ex){ModelState.AddModelError("",ex.Message);}input.Password=null;ModelState.Remove(nameof(input.Password));return View("StaffMember",input);}
 public IActionResult StockCount(int variantId,int warehouseId)
 {var data=store.Read(d=>d);if(!data.Variants.Any(v=>v.Id==variantId)||!data.Warehouses.Any(w=>w.Id==warehouseId&&w.Active))return NotFound();ViewBag.VariantId=variantId;ViewBag.WarehouseId=warehouseId;return View(data);}
 public IActionResult ReturnRequest(int id)
 {var r=store.Read(d=>d.Returns.FirstOrDefault(r=>r.Id==id));return r==null?NotFound():View(new List<ReturnRecord>{r});}
 public IActionResult EditCustomer(int id)
 {var c=store.Read(d=>d.Customers.FirstOrDefault(c=>c.Id==id&&c.Role=="Customer"));if(c==null)return NotFound();ViewBag.Id=id;ViewBag.Active=c.Active;return View(new ProfileInput{Name=c.Name,Phone=c.Phone,Address=c.Address});}
 [HttpPost] public IActionResult EditCustomer(int id,ProfileInput input,bool active)
 {ViewBag.Id=id;ViewBag.Active=active;if(ModelState.IsValid)try{store.UpdateCustomer(id,input,active,ActorId);TempData["Success"]="Đã cập nhật khách hàng.";return RedirectToAction(nameof(Customer),new{id});}catch(InvalidOperationException ex){ModelState.AddModelError("",ex.Message);}return View(input);}
 public IActionResult Reviews()=>View(store.Reviews(includeHidden:true));
 [HttpPost] public IActionResult Moderate(int id,bool active){try{store.ModerateReview(id,active,ActorId);}catch(InvalidOperationException ex){TempData["Error"]=ex.Message;}return RedirectToAction(nameof(Reviews));}
 public IActionResult LoginHistory()=>View(store.NativeRead(db=>db.LichSuDangNhap.OrderByDescending(x=>x.MaLichSu).Take(300).ToList()));
}

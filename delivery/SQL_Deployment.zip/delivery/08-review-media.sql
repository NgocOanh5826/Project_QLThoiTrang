:ON ERROR EXIT
USE [$(DatabaseName)];
GO
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF OBJECT_ID(N'dbo.DanhGia',N'U') IS NULL THROW 51000,'Missing DanhGia table; install the base schema first.',1;
IF OBJECT_ID(N'dbo.QOANH_ReviewMedia',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.QOANH_ReviewMedia(
  Id uniqueidentifier NOT NULL CONSTRAINT PK_QOANH_ReviewMedia PRIMARY KEY,
  ReviewId int NOT NULL,
  ContentType varchar(30) NOT NULL,
  Content varbinary(max) NOT NULL,
  CONSTRAINT FK_QOANH_ReviewMedia_Review FOREIGN KEY(ReviewId) REFERENCES dbo.DanhGia(MaDanhGia),
  CONSTRAINT CK_QOANH_ReviewMedia_Type CHECK(ContentType IN ('image/jpeg','image/png','image/gif','image/webp','video/mp4','video/webm')),
  CONSTRAINT CK_QOANH_ReviewMedia_Size CHECK(DATALENGTH(Content)>0 AND DATALENGTH(Content)<=20971520 AND (ContentType LIKE 'video/%' OR DATALENGTH(Content)<=5242880))
 );
 CREATE INDEX IX_QOANH_ReviewMedia_ReviewId ON dbo.QOANH_ReviewMedia(ReviewId);
END;
COMMIT;
GO
